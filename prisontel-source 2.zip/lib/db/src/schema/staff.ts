import { pgTable, text, serial, timestamp, integer, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const staffRoleEnum = pgEnum("staff_role", ["admin", "supervisor", "officer", "analyst", "operator"]);
export const staffStatusEnum = pgEnum("staff_status", ["active", "inactive", "suspended"]);
export const shiftEnum = pgEnum("shift", ["day", "evening", "night"]);

export const staffTable = pgTable("staff", {
  id: serial("id").primaryKey(),
  facilityId: integer("facility_id").notNull(),
  employeeId: text("employee_id").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  role: staffRoleEnum("role").notNull(),
  status: staffStatusEnum("status").notNull().default("active"),
  department: text("department"),
  shift: shiftEnum("shift"),
  hireDate: text("hire_date"),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  permissions: text("permissions").array().notNull().default([]),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertStaffSchema = createInsertSchema(staffTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertStaff = z.infer<typeof insertStaffSchema>;
export type Staff = typeof staffTable.$inferSelect;
