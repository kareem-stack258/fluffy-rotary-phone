import { pgTable, text, serial, timestamp, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recordingStatusEnum = pgEnum("recording_status", ["processing", "available", "archived", "deleted"]);
export const recordingFormatEnum = pgEnum("recording_format", ["mp3", "wav", "ogg"]);

export const recordingsTable = pgTable("recordings", {
  id: serial("id").primaryKey(),
  callId: integer("call_id").notNull(),
  inmateId: integer("inmate_id").notNull(),
  facilityId: integer("facility_id").notNull(),
  status: recordingStatusEnum("status").notNull().default("available"),
  durationSeconds: integer("duration_seconds").notNull(),
  fileSizeBytes: integer("file_size_bytes").notNull(),
  fileUrl: text("file_url"),
  format: recordingFormatEnum("format").notNull().default("mp3"),
  isReviewed: boolean("is_reviewed").notNull().default(false),
  reviewedBy: integer("reviewed_by"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  reviewNotes: text("review_notes"),
  retentionDays: integer("retention_days").notNull().default(90),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertRecordingSchema = createInsertSchema(recordingsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertRecording = z.infer<typeof insertRecordingSchema>;
export type Recording = typeof recordingsTable.$inferSelect;
