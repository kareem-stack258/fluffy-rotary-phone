import { pgTable, text, serial, timestamp, integer, boolean, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const callStatusEnum = pgEnum("call_status", ["scheduled", "active", "completed", "failed", "blocked", "flagged"]);
export const callDirectionEnum = pgEnum("call_direction", ["inbound", "outbound"]);

export const callsTable = pgTable("calls", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull(),
  contactId: integer("contact_id"),
  facilityId: integer("facility_id").notNull(),
  direction: callDirectionEnum("direction").notNull().default("outbound"),
  status: callStatusEnum("status").notNull().default("completed"),
  phoneNumber: text("phone_number").notNull(),
  durationSeconds: integer("duration_seconds"),
  costAmount: numeric("cost_amount", { precision: 10, scale: 4 }),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  isFlagged: boolean("is_flagged").notNull().default(false),
  flagReason: text("flag_reason"),
  flaggedBy: integer("flagged_by"),
  terminatedBy: integer("terminated_by"),
  recordingId: integer("recording_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCallSchema = createInsertSchema(callsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCall = z.infer<typeof insertCallSchema>;
export type Call = typeof callsTable.$inferSelect;
