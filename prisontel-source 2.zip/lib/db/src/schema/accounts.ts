import { pgTable, text, serial, timestamp, integer, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const accountStatusEnum = pgEnum("account_status", ["active", "frozen", "closed"]);

export const accountsTable = pgTable("accounts", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull().unique(),
  facilityId: integer("facility_id").notNull(),
  balance: numeric("balance", { precision: 12, scale: 2 }).notNull().default("0.00"),
  pendingBalance: numeric("pending_balance", { precision: 12, scale: 2 }).notNull().default("0.00"),
  status: accountStatusEnum("status").notNull().default("active"),
  totalDeposited: numeric("total_deposited", { precision: 12, scale: 2 }).notNull().default("0.00"),
  totalSpent: numeric("total_spent", { precision: 12, scale: 2 }).notNull().default("0.00"),
  lastDepositAmount: numeric("last_deposit_amount", { precision: 12, scale: 2 }),
  lastDepositAt: timestamp("last_deposit_at", { withTimezone: true }),
  lastActivityAt: timestamp("last_activity_at", { withTimezone: true }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAccountSchema = createInsertSchema(accountsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Account = typeof accountsTable.$inferSelect;
