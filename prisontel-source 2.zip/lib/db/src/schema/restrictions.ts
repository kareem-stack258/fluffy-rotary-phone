import { pgTable, text, serial, timestamp, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const restrictionTypeEnum = pgEnum("restriction_type", ["blocked_number", "time_limit", "total_ban", "schedule_only"]);

export const restrictionsTable = pgTable("restrictions", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull(),
  facilityId: integer("facility_id"),
  type: restrictionTypeEnum("type").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  blockedNumber: text("blocked_number"),
  dailyLimitMinutes: integer("daily_limit_minutes"),
  allowedStartTime: text("allowed_start_time"),
  allowedEndTime: text("allowed_end_time"),
  allowedDays: text("allowed_days").array().notNull().default([]),
  reason: text("reason").notNull(),
  createdBy: integer("created_by"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertRestrictionSchema = createInsertSchema(restrictionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertRestriction = z.infer<typeof insertRestrictionSchema>;
export type Restriction = typeof restrictionsTable.$inferSelect;
