import { pgTable, text, serial, timestamp, integer, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const transactionTypeEnum = pgEnum("transaction_type", ["deposit", "call_charge", "message_charge", "refund", "adjustment", "fee"]);
export const paymentMethodEnum = pgEnum("payment_method", ["cash", "credit_card", "money_order", "kiosk", "online"]);

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull(),
  callId: integer("call_id"),
  messageId: integer("message_id"),
  type: transactionTypeEnum("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 4 }).notNull(),
  balanceBefore: numeric("balance_before", { precision: 12, scale: 4 }).notNull(),
  balanceAfter: numeric("balance_after", { precision: 12, scale: 4 }).notNull(),
  description: text("description").notNull(),
  reference: text("reference"),
  paymentMethod: paymentMethodEnum("payment_method"),
  processedBy: integer("processed_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({ id: true, createdAt: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
