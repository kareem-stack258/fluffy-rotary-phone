import { pgTable, text, serial, timestamp, integer, boolean, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const messageStatusEnum = pgEnum("message_status", ["pending", "approved", "delivered", "rejected", "flagged"]);
export const messageDirectionEnum = pgEnum("message_direction", ["inbound", "outbound"]);

export const messagesTable = pgTable("messages", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull(),
  contactId: integer("contact_id"),
  facilityId: integer("facility_id").notNull(),
  direction: messageDirectionEnum("direction").notNull(),
  status: messageStatusEnum("status").notNull().default("pending"),
  senderName: text("sender_name").notNull(),
  recipientName: text("recipient_name").notNull(),
  recipientPhone: text("recipient_phone"),
  recipientEmail: text("recipient_email"),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  wordCount: integer("word_count").notNull().default(0),
  costAmount: numeric("cost_amount", { precision: 10, scale: 4 }),
  isFlagged: boolean("is_flagged").notNull().default(false),
  flagReason: text("flag_reason"),
  reviewedBy: integer("reviewed_by"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  rejectionReason: text("rejection_reason"),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertMessageSchema = createInsertSchema(messagesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messagesTable.$inferSelect;
