import { pgTable, text, serial, timestamp, integer, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const facilityTypeEnum = pgEnum("facility_type", ["federal", "state", "county", "private", "juvenile"]);
export const facilityStatusEnum = pgEnum("facility_status", ["active", "inactive", "under_renovation"]);

export const facilitiesTable = pgTable("facilities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  type: facilityTypeEnum("type").notNull(),
  status: facilityStatusEnum("status").notNull().default("active"),
  address: text("address").notNull(),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  phone: text("phone"),
  capacity: integer("capacity").notNull(),
  currentPopulation: integer("current_population").notNull().default(0),
  dailyCallLimitMinutes: integer("daily_call_limit_minutes").notNull().default(60),
  callRatePerMinute: numeric("call_rate_per_minute", { precision: 10, scale: 4 }).notNull().default("0.21"),
  messageRateEach: numeric("message_rate_each", { precision: 10, scale: 4 }).notNull().default("0.35"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertFacilitySchema = createInsertSchema(facilitiesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertFacility = z.infer<typeof insertFacilitySchema>;
export type Facility = typeof facilitiesTable.$inferSelect;
