import { pgTable, text, serial, timestamp, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const inmateStatusEnum = pgEnum("inmate_status", ["active", "transferred", "released", "deceased"]);
export const securityLevelEnum = pgEnum("security_level", ["minimum", "medium", "maximum", "supermax"]);
export const genderEnum = pgEnum("gender", ["male", "female", "non_binary", "other"]);

export const inmatesTable = pgTable("inmates", {
  id: serial("id").primaryKey(),
  facilityId: integer("facility_id").notNull(),
  inmateNumber: text("inmate_number").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  middleName: text("middle_name"),
  dateOfBirth: text("date_of_birth"),
  gender: genderEnum("gender").notNull().default("male"),
  status: inmateStatusEnum("status").notNull().default("active"),
  securityLevel: securityLevelEnum("security_level").notNull().default("medium"),
  housingUnit: text("housing_unit").notNull(),
  cell: text("cell"),
  admissionDate: text("admission_date").notNull(),
  releaseDate: text("release_date"),
  offense: text("offense"),
  callsAllowed: boolean("calls_allowed").notNull().default(true),
  messagesAllowed: boolean("messages_allowed").notNull().default(true),
  dailyCallLimitOverrideMinutes: integer("daily_call_limit_override_minutes"),
  photoUrl: text("photo_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertInmateSchema = createInsertSchema(inmatesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertInmate = z.infer<typeof insertInmateSchema>;
export type Inmate = typeof inmatesTable.$inferSelect;
