import { pgTable, text, serial, timestamp, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const contactStatusEnum = pgEnum("contact_status", ["pending", "approved", "rejected", "revoked"]);
export const relationshipEnum = pgEnum("relationship", ["spouse", "parent", "child", "sibling", "other_family", "friend", "attorney", "clergy"]);

export const contactsTable = pgTable("contacts", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  alternatePhone: text("alternate_phone"),
  email: text("email"),
  relationship: relationshipEnum("relationship").notNull(),
  status: contactStatusEnum("status").notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  revocationReason: text("revocation_reason"),
  approvedBy: integer("approved_by"),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  idVerified: boolean("id_verified").notNull().default(false),
  backgroundCheckPassed: boolean("background_check_passed"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertContactSchema = createInsertSchema(contactsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contactsTable.$inferSelect;
