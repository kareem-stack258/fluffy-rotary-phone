import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const schedulesTable = pgTable("schedules", {
  id: serial("id").primaryKey(),
  inmateId: integer("inmate_id").notNull(),
  facilityId: integer("facility_id").notNull(),
  name: text("name").notNull(),
  daysOfWeek: text("days_of_week").array().notNull().default([]),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  maxDurationMinutes: integer("max_duration_minutes"),
  isActive: boolean("is_active").notNull().default(true),
  effectiveFrom: text("effective_from"),
  effectiveUntil: text("effective_until"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertScheduleSchema = createInsertSchema(schedulesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedulesTable.$inferSelect;
