import { db } from "@workspace/db";
import {
  facilitiesTable, inmatesTable, staffTable, contactsTable,
  callsTable, messagesTable, accountsTable, transactionsTable,
  alertsTable, recordingsTable, restrictionsTable, schedulesTable,
} from "@workspace/db";
import { sql } from "drizzle-orm";

async function seed() {
  console.log("Seeding PrisonTel database...");

  // Truncate in reverse dependency order
  await db.execute(sql`truncate table schedules, restrictions, recordings, alerts, transactions, accounts, messages, calls, contacts, staff, inmates, facilities restart identity cascade`);

  // ─── FACILITIES ────────────────────────────────────────────────────────────
  const [f1] = await db.insert(facilitiesTable).values({
    name: "Riverbend Maximum Security Institution",
    code: "RMSI",
    type: "state",
    status: "active",
    address: "1 Prison Drive",
    city: "Nashville",
    state: "TN",
    capacity: 1200,
    currentPopulation: 1087,
    dailyCallLimitMinutes: 60,
    callRatePerMinute: "0.21",
    messageRateEach: "0.35",
  }).returning();

  const [f2] = await db.insert(facilitiesTable).values({
    name: "Shelby County Correctional Center",
    code: "SCCC",
    type: "county",
    status: "active",
    address: "201 Poplar Ave",
    city: "Memphis",
    state: "TN",
    capacity: 600,
    currentPopulation: 512,
    dailyCallLimitMinutes: 45,
    callRatePerMinute: "0.19",
    messageRateEach: "0.30",
  }).returning();

  const [f3] = await db.insert(facilitiesTable).values({
    name: "Federal Correctional Institute Carswell",
    code: "FCIC",
    type: "federal",
    status: "active",
    address: "100 NAS Drive",
    city: "Fort Worth",
    state: "TX",
    capacity: 1500,
    currentPopulation: 1341,
    dailyCallLimitMinutes: 30,
    callRatePerMinute: "0.25",
    messageRateEach: "0.40",
  }).returning();

  // ─── STAFF ─────────────────────────────────────────────────────────────────
  const [s1] = await db.insert(staffTable).values({
    facilityId: f1.id,
    employeeId: "EMP-001",
    firstName: "Marcus",
    lastName: "Webb",
    email: "m.webb@rmsi.tn.gov",
    role: "admin",
    status: "active",
    department: "Administration",
    shift: "day",
    permissions: ["all"],
  }).returning();

  const [s2] = await db.insert(staffTable).values({
    facilityId: f1.id,
    employeeId: "EMP-002",
    firstName: "Diana",
    lastName: "Torres",
    email: "d.torres@rmsi.tn.gov",
    role: "supervisor",
    status: "active",
    department: "Communications",
    shift: "day",
    permissions: ["calls", "messages", "alerts"],
  }).returning();

  await db.insert(staffTable).values({
    facilityId: f1.id,
    employeeId: "EMP-003",
    firstName: "James",
    lastName: "Holloway",
    email: "j.holloway@rmsi.tn.gov",
    role: "officer",
    status: "active",
    department: "Security",
    shift: "evening",
    permissions: ["calls", "alerts"],
  }).returning();

  await db.insert(staffTable).values({
    facilityId: f2.id,
    employeeId: "EMP-004",
    firstName: "Sarah",
    lastName: "Nguyen",
    email: "s.nguyen@sccc.shelby.tn.gov",
    role: "analyst",
    status: "active",
    department: "Intelligence",
    shift: "day",
    permissions: ["reports", "recordings"],
  }).returning();

  await db.insert(staffTable).values({
    facilityId: f3.id,
    employeeId: "EMP-005",
    firstName: "Robert",
    lastName: "King",
    email: "r.king@bop.gov",
    role: "operator",
    status: "active",
    department: "Telecommunications",
    shift: "night",
    permissions: ["calls"],
  }).returning();

  // ─── INMATES ───────────────────────────────────────────────────────────────
  const inmates = await db.insert(inmatesTable).values([
    {
      facilityId: f1.id,
      inmateNumber: "INM-2019-0441",
      firstName: "Daniel",
      lastName: "Reeves",
      dateOfBirth: "1981-03-14",
      gender: "male",
      status: "active",
      securityLevel: "maximum",
      housingUnit: "Block D",
      cell: "D-14",
      admissionDate: "2019-06-01",
      releaseDate: "2034-06-01",
      offense: "Armed Robbery, Assault",
      callsAllowed: true,
      messagesAllowed: true,
    },
    {
      facilityId: f1.id,
      inmateNumber: "INM-2021-0883",
      firstName: "Terrence",
      lastName: "Jackson",
      dateOfBirth: "1990-11-22",
      gender: "male",
      status: "active",
      securityLevel: "medium",
      housingUnit: "Block B",
      cell: "B-07",
      admissionDate: "2021-02-15",
      releaseDate: "2026-02-15",
      offense: "Drug Trafficking",
      callsAllowed: true,
      messagesAllowed: true,
    },
    {
      facilityId: f1.id,
      inmateNumber: "INM-2020-0556",
      firstName: "Marcus",
      lastName: "Greene",
      dateOfBirth: "1976-07-08",
      gender: "male",
      status: "active",
      securityLevel: "supermax",
      housingUnit: "Block F",
      cell: "F-01",
      admissionDate: "2020-09-10",
      releaseDate: "2055-09-10",
      offense: "Murder, Gang Activity",
      callsAllowed: false,
      messagesAllowed: false,
    },
    {
      facilityId: f2.id,
      inmateNumber: "INM-2022-1102",
      firstName: "Alicia",
      lastName: "Morgan",
      dateOfBirth: "1995-01-30",
      gender: "female",
      status: "active",
      securityLevel: "minimum",
      housingUnit: "Unit A",
      cell: "A-22",
      admissionDate: "2022-08-20",
      releaseDate: "2025-08-20",
      offense: "Fraud, Identity Theft",
      callsAllowed: true,
      messagesAllowed: true,
    },
    {
      facilityId: f2.id,
      inmateNumber: "INM-2023-0210",
      firstName: "Carlos",
      lastName: "Vega",
      dateOfBirth: "1988-05-19",
      gender: "male",
      status: "active",
      securityLevel: "medium",
      housingUnit: "Unit B",
      cell: "B-15",
      admissionDate: "2023-01-12",
      releaseDate: "2027-01-12",
      offense: "Carjacking",
      callsAllowed: true,
      messagesAllowed: false,
    },
    {
      facilityId: f3.id,
      inmateNumber: "INM-2018-0091",
      firstName: "Priya",
      lastName: "Sharma",
      dateOfBirth: "1973-09-04",
      gender: "female",
      status: "active",
      securityLevel: "medium",
      housingUnit: "Unit C",
      cell: "C-08",
      admissionDate: "2018-11-30",
      releaseDate: "2028-11-30",
      offense: "Federal Conspiracy, Money Laundering",
      callsAllowed: true,
      messagesAllowed: true,
    },
    {
      facilityId: f1.id,
      inmateNumber: "INM-2024-0337",
      firstName: "Devon",
      lastName: "Brooks",
      dateOfBirth: "2000-04-17",
      gender: "male",
      status: "active",
      securityLevel: "minimum",
      housingUnit: "Block A",
      cell: "A-04",
      admissionDate: "2024-03-01",
      releaseDate: "2026-03-01",
      offense: "Burglary",
      callsAllowed: true,
      messagesAllowed: true,
    },
  ]).returning();

  const [i1, i2, i3, i4, i5, i6, i7] = inmates;

  // ─── CONTACTS ──────────────────────────────────────────────────────────────
  const contacts = await db.insert(contactsTable).values([
    { inmateId: i1.id, firstName: "Sandra", lastName: "Reeves", phoneNumber: "615-555-0101", relationship: "spouse", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2019-07-01") },
    { inmateId: i1.id, firstName: "Frank", lastName: "Reeves", phoneNumber: "615-555-0102", relationship: "parent", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2019-07-01") },
    { inmateId: i1.id, firstName: "Ray", lastName: "Dobbins", phoneNumber: "615-555-0199", relationship: "friend", status: "pending", idVerified: false },
    { inmateId: i2.id, firstName: "Keisha", lastName: "Jackson", phoneNumber: "901-555-0201", relationship: "sibling", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2021-03-01") },
    { inmateId: i2.id, firstName: "Gerald", lastName: "Moss", phoneNumber: "901-555-0299", relationship: "friend", status: "pending", idVerified: false },
    { inmateId: i4.id, firstName: "Helen", lastName: "Morgan", phoneNumber: "901-555-0401", relationship: "parent", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2022-09-01") },
    { inmateId: i4.id, firstName: "David", lastName: "Chase", phoneNumber: "901-555-0402", relationship: "attorney", status: "pending", idVerified: false },
    { inmateId: i5.id, firstName: "Elena", lastName: "Vega", phoneNumber: "901-555-0501", relationship: "spouse", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2023-02-01") },
    { inmateId: i6.id, firstName: "Rajiv", lastName: "Sharma", phoneNumber: "817-555-0601", relationship: "spouse", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2019-01-01") },
    { inmateId: i7.id, firstName: "Carol", lastName: "Brooks", phoneNumber: "615-555-0701", relationship: "parent", status: "approved", idVerified: true, backgroundCheckPassed: true, approvedAt: new Date("2024-03-15") },
    { inmateId: i1.id, firstName: "Johnny", lastName: "Malone", phoneNumber: "615-555-0198", relationship: "friend", status: "rejected", rejectionReason: "Failed background check" },
  ]).returning();

  // ─── CALLS ─────────────────────────────────────────────────────────────────
  const now = new Date();
  function daysAgo(d: number) { return new Date(now.getTime() - d * 86400000); }
  function minsAgo(m: number) { return new Date(now.getTime() - m * 60000); }

  const calls = await db.insert(callsTable).values([
    { inmateId: i1.id, contactId: contacts[0].id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: contacts[0].phoneNumber, durationSeconds: 843, costAmount: "2.97", startedAt: daysAgo(1), endedAt: new Date(daysAgo(1).getTime() + 843000), isFlagged: false },
    { inmateId: i1.id, contactId: contacts[1].id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: contacts[1].phoneNumber, durationSeconds: 1200, costAmount: "4.20", startedAt: daysAgo(3), endedAt: new Date(daysAgo(3).getTime() + 1200000), isFlagged: false },
    { inmateId: i2.id, contactId: contacts[3].id, facilityId: f1.id, direction: "outbound", status: "flagged", phoneNumber: contacts[3].phoneNumber, durationSeconds: 2100, costAmount: "7.35", startedAt: daysAgo(2), endedAt: new Date(daysAgo(2).getTime() + 2100000), isFlagged: true, flagReason: "Coded language suspected — referenced package drop" },
    { inmateId: i2.id, contactId: contacts[3].id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: contacts[3].phoneNumber, durationSeconds: 600, costAmount: "2.10", startedAt: daysAgo(5), endedAt: new Date(daysAgo(5).getTime() + 600000), isFlagged: false },
    { inmateId: i4.id, contactId: contacts[5].id, facilityId: f2.id, direction: "outbound", status: "active", phoneNumber: contacts[5].phoneNumber, durationSeconds: null, costAmount: null, startedAt: minsAgo(12), endedAt: null, isFlagged: false },
    { inmateId: i4.id, contactId: contacts[5].id, facilityId: f2.id, direction: "outbound", status: "completed", phoneNumber: contacts[5].phoneNumber, durationSeconds: 450, costAmount: "1.43", startedAt: daysAgo(1), endedAt: new Date(daysAgo(1).getTime() + 450000), isFlagged: false },
    { inmateId: i5.id, contactId: contacts[7].id, facilityId: f2.id, direction: "outbound", status: "blocked", phoneNumber: contacts[7].phoneNumber, durationSeconds: 0, costAmount: "0.00", startedAt: daysAgo(0), endedAt: new Date(), isFlagged: false },
    { inmateId: i6.id, contactId: contacts[8].id, facilityId: f3.id, direction: "outbound", status: "active", phoneNumber: contacts[8].phoneNumber, durationSeconds: null, costAmount: null, startedAt: minsAgo(5), endedAt: null, isFlagged: false },
    { inmateId: i6.id, contactId: contacts[8].id, facilityId: f3.id, direction: "outbound", status: "flagged", phoneNumber: contacts[8].phoneNumber, durationSeconds: 3600, costAmount: "15.00", startedAt: daysAgo(4), endedAt: new Date(daysAgo(4).getTime() + 3600000), isFlagged: true, flagReason: "Discussed financial transfers with unauthorized third party" },
    { inmateId: i7.id, contactId: contacts[9].id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: contacts[9].phoneNumber, durationSeconds: 300, costAmount: "1.05", startedAt: daysAgo(1), endedAt: new Date(daysAgo(1).getTime() + 300000), isFlagged: false },
    { inmateId: i1.id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: "615-555-0103", durationSeconds: 720, costAmount: "2.52", startedAt: daysAgo(7), endedAt: new Date(daysAgo(7).getTime() + 720000), isFlagged: false },
    { inmateId: i2.id, facilityId: f1.id, direction: "outbound", status: "completed", phoneNumber: contacts[3].phoneNumber, durationSeconds: 900, costAmount: "3.15", startedAt: daysAgo(10), endedAt: new Date(daysAgo(10).getTime() + 900000), isFlagged: false },
  ]).returning();

  // ─── RECORDINGS ────────────────────────────────────────────────────────────
  await db.insert(recordingsTable).values([
    { callId: calls[0].id, inmateId: i1.id, facilityId: f1.id, status: "available", durationSeconds: 843, fileSizeBytes: 8430000, format: "mp3", isReviewed: true, reviewNotes: "Routine family conversation. No concerns.", retentionDays: 90, expiresAt: new Date(now.getTime() + 90 * 86400000) },
    { callId: calls[2].id, inmateId: i2.id, facilityId: f1.id, status: "available", durationSeconds: 2100, fileSizeBytes: 21000000, format: "mp3", isReviewed: false, retentionDays: 180, expiresAt: new Date(now.getTime() + 180 * 86400000) },
    { callId: calls[8].id, inmateId: i6.id, facilityId: f3.id, status: "available", durationSeconds: 3600, fileSizeBytes: 36000000, format: "mp3", isReviewed: false, retentionDays: 180, expiresAt: new Date(now.getTime() + 180 * 86400000) },
    { callId: calls[1].id, inmateId: i1.id, facilityId: f1.id, status: "available", durationSeconds: 1200, fileSizeBytes: 12000000, format: "mp3", isReviewed: true, reviewNotes: "Discussing appeal with family attorney. Privileged but flagged per policy.", retentionDays: 90, expiresAt: new Date(now.getTime() + 90 * 86400000) },
    { callId: calls[9].id, inmateId: i7.id, facilityId: f1.id, status: "available", durationSeconds: 300, fileSizeBytes: 3000000, format: "mp3", isReviewed: true, reviewNotes: "Brief family check-in.", retentionDays: 90, expiresAt: new Date(now.getTime() + 90 * 86400000) },
  ]);

  // ─── MESSAGES ──────────────────────────────────────────────────────────────
  await db.insert(messagesTable).values([
    { inmateId: i1.id, facilityId: f1.id, direction: "outbound", status: "approved", senderName: "Daniel Reeves", recipientName: "Sandra Reeves", subject: "Weekend Visit Request", body: "Sandra, wanted to let you know visitation is now open Saturdays. Can you come next week? I miss the kids. Please bring the photos from Christmas. Love, Daniel.", wordCount: 34, costAmount: "0.35", isFlagged: false, reviewedAt: daysAgo(1) },
    { inmateId: i1.id, facilityId: f1.id, direction: "inbound", status: "pending", senderName: "Sandra Reeves", recipientName: "Daniel Reeves", subject: "Re: Weekend Visit", body: "Daniel, yes we will be there Saturday at 10. The kids made drawings for you. We're all thinking about you every day and staying strong. Sandra.", wordCount: 33, costAmount: "0.35", isFlagged: false },
    { inmateId: i2.id, facilityId: f1.id, direction: "outbound", status: "flagged", senderName: "Terrence Jackson", recipientName: "Keisha Jackson", subject: "Property Matters", body: "Keisha, remember the blue car in Uncle Earl's garage. Tell Marcus to move the package before Thursday. The people who are watching need their answer by then. Thanks.", wordCount: 31, costAmount: "0.35", isFlagged: true, flagReason: "Suspected coded coordination for contraband delivery" },
    { inmateId: i4.id, facilityId: f2.id, direction: "outbound", status: "pending", senderName: "Alicia Morgan", recipientName: "Helen Morgan", subject: "Legal Update", body: "Mom, my attorney says the appeal has a strong chance. The judge reviewing my case has reversed similar sentences before. I need you to gather the bank records from 2021 and send copies to the law office.", wordCount: 43, costAmount: "0.35", isFlagged: false },
    { inmateId: i4.id, facilityId: f2.id, direction: "inbound", status: "approved", senderName: "Helen Morgan", recipientName: "Alicia Morgan", subject: "Thinking of you", body: "Alicia sweetheart, we are all praying for you every day. The whole family came together for Thanksgiving this year. Pastor Williams asked about you. Stay faithful and stay strong.", wordCount: 31, costAmount: "0.35", isFlagged: false, reviewedAt: daysAgo(2) },
    { inmateId: i6.id, facilityId: f3.id, direction: "outbound", status: "rejected", senderName: "Priya Sharma", recipientName: "Vikram Patel", subject: "Investment Inquiry", body: "Vikram, as discussed on the call, please initiate the transfer of the funds to the Cayman account. Use the routing we established in March 2023. Confirm receipt.", wordCount: 30, costAmount: "0.35", isFlagged: true, flagReason: "Potential financial crime coordination", rejectionReason: "Suspected wire fraud facilitation", reviewedAt: daysAgo(3) },
    { inmateId: i7.id, facilityId: f1.id, direction: "outbound", status: "approved", senderName: "Devon Brooks", recipientName: "Carol Brooks", subject: "GED Progress", body: "Mom, just wanted to let you know I passed my math GED exam with a 82. The counselor says if I finish the program I can get early release consideration. Working hard every day.", wordCount: 37, costAmount: "0.35", isFlagged: false, reviewedAt: daysAgo(1) },
  ]);

  // ─── ACCOUNTS ──────────────────────────────────────────────────────────────
  const accts = await db.insert(accountsTable).values([
    { inmateId: i1.id, facilityId: f1.id, balance: "47.83", pendingBalance: "0.00", status: "active", totalDeposited: "200.00", totalSpent: "152.17", lastDepositAmount: "50.00", lastDepositAt: daysAgo(14), lastActivityAt: daysAgo(1) },
    { inmateId: i2.id, facilityId: f1.id, balance: "3.40", pendingBalance: "0.00", status: "active", totalDeposited: "120.00", totalSpent: "116.60", lastDepositAmount: "20.00", lastDepositAt: daysAgo(30), lastActivityAt: daysAgo(2) },
    { inmateId: i3.id, facilityId: f1.id, balance: "0.00", pendingBalance: "0.00", status: "frozen", totalDeposited: "0.00", totalSpent: "0.00" },
    { inmateId: i4.id, facilityId: f2.id, balance: "128.50", pendingBalance: "0.35", status: "active", totalDeposited: "500.00", totalSpent: "371.50", lastDepositAmount: "100.00", lastDepositAt: daysAgo(7), lastActivityAt: daysAgo(0) },
    { inmateId: i5.id, facilityId: f2.id, balance: "15.20", pendingBalance: "0.00", status: "active", totalDeposited: "80.00", totalSpent: "64.80", lastDepositAmount: "30.00", lastDepositAt: daysAgo(21), lastActivityAt: daysAgo(5) },
    { inmateId: i6.id, facilityId: f3.id, balance: "892.10", pendingBalance: "0.00", status: "active", totalDeposited: "2400.00", totalSpent: "1507.90", lastDepositAmount: "300.00", lastDepositAt: daysAgo(5), lastActivityAt: daysAgo(0) },
    { inmateId: i7.id, facilityId: f1.id, balance: "22.75", pendingBalance: "0.00", status: "active", totalDeposited: "75.00", totalSpent: "52.25", lastDepositAmount: "25.00", lastDepositAt: daysAgo(10), lastActivityAt: daysAgo(1) },
  ]).returning();

  // ─── TRANSACTIONS ──────────────────────────────────────────────────────────
  await db.insert(transactionsTable).values([
    { accountId: accts[0].id, type: "deposit", amount: "50.00", balanceBefore: "0.00", balanceAfter: "50.00", description: "Family deposit via kiosk", paymentMethod: "kiosk" },
    { accountId: accts[0].id, type: "call_charge", amount: "2.97", balanceBefore: "50.00", balanceAfter: "47.03", description: "Call to 615-555-0101 (14m 3s)" },
    { accountId: accts[1].id, type: "deposit", amount: "20.00", balanceBefore: "0.00", balanceAfter: "20.00", description: "Money order received", paymentMethod: "money_order" },
    { accountId: accts[1].id, type: "call_charge", amount: "7.35", balanceBefore: "10.75", balanceAfter: "3.40", description: "Call to 901-555-0201 (35m)" },
    { accountId: accts[3].id, type: "deposit", amount: "100.00", balanceBefore: "28.85", balanceAfter: "128.85", description: "Online deposit by family", paymentMethod: "online" },
    { accountId: accts[3].id, type: "message_charge", amount: "0.35", balanceBefore: "128.85", balanceAfter: "128.50", description: "Outbound message: Weekend Visit Request" },
    { accountId: accts[5].id, type: "deposit", amount: "300.00", balanceBefore: "607.45", balanceAfter: "907.45", description: "Attorney trust deposit", paymentMethod: "credit_card" },
    { accountId: accts[5].id, type: "call_charge", amount: "15.00", balanceBefore: "907.45", balanceAfter: "892.45", description: "Call to 817-555-0601 (60m)" },
    { accountId: accts[6].id, type: "deposit", amount: "25.00", balanceBefore: "0.00", balanceAfter: "25.00", description: "Cash deposit at facility", paymentMethod: "cash" },
    { accountId: accts[6].id, type: "message_charge", amount: "0.35", balanceBefore: "25.00", balanceAfter: "24.65", description: "Outbound message: GED Progress" },
  ]);

  // ─── ALERTS ────────────────────────────────────────────────────────────────
  await db.insert(alertsTable).values([
    { facilityId: f1.id, inmateId: i2.id, type: "flagged_call", severity: "critical", status: "open", title: "Coded Communication — Suspected Contraband Coordination", description: 'Call ID flagged for coded language. Terrence Jackson referenced "moving the package before Thursday" in context with known associate. Possible drug drop coordination.', assignedTo: s2.id },
    { facilityId: f3.id, inmateId: i6.id, type: "flagged_message", severity: "critical", status: "investigating", title: "Wire Fraud Facilitation — Cayman Account Transfer", description: "Outgoing message from Priya Sharma to Vikram Patel instructing Cayman Island fund transfer using pre-established routing. Referred to federal financial crimes unit.", assignedTo: s1.id, resolvedAt: null },
    { facilityId: f3.id, inmateId: i6.id, type: "flagged_call", severity: "high", status: "investigating", title: "Unauthorized Financial Discussion — Third Party", description: "60-minute call contained discussion of financial transfers to unnamed third party. Corroborated by flagged message. Building case file.", assignedTo: s1.id },
    { facilityId: f1.id, inmateId: i1.id, type: "suspicious_activity", severity: "medium", status: "open", title: "Unusual Contact Request — Background Check Pending", description: "Third contact request from Ray Dobbins submitted for Inmate Daniel Reeves. Previous contact request from same name was rejected in 2021. Identity verification required." },
    { facilityId: f2.id, inmateId: i5.id, type: "policy_violation", severity: "low", status: "resolved", title: "Attempted Call to Blocked Number", description: "Carlos Vega attempted to place call to blocked number 901-555-0501 at 14:22. Call was automatically blocked by system. Standard incident documented.", resolvedBy: s2.id, resolvedAt: daysAgo(0), resolutionNotes: "System auto-blocked. Inmate counseled regarding communication restrictions." },
    { facilityId: f1.id, type: "account_fraud", severity: "medium", status: "open", title: "Low Balance Alert — Risk of Service Disruption", description: "Terrence Jackson account balance below $5.00 threshold. Account has not received deposit in 30+ days. Family contact recommended by case manager." },
  ]);

  // ─── RESTRICTIONS ──────────────────────────────────────────────────────────
  await db.insert(restrictionsTable).values([
    { inmateId: i3.id, facilityId: f1.id, type: "total_ban", isActive: true, reason: "Supermax classification — all communications suspended pending disciplinary review", createdBy: s1.id, allowedDays: [] },
    { inmateId: i5.id, facilityId: f2.id, type: "blocked_number", isActive: true, blockedNumber: "901-555-0501", reason: "Contact associated with criminal enterprise — court order", createdBy: s2.id, allowedDays: [] },
    { inmateId: i2.id, facilityId: f1.id, type: "time_limit", isActive: true, dailyLimitMinutes: 15, reason: "Disciplinary sanction — reduced call privileges for 90 days", createdBy: s2.id, allowedDays: [] },
    { inmateId: i6.id, facilityId: f3.id, type: "schedule_only", isActive: true, allowedStartTime: "10:00", allowedEndTime: "11:00", allowedDays: ["monday", "wednesday", "friday"], reason: "Court-ordered communication monitoring schedule", createdBy: s1.id },
  ]);

  // ─── SCHEDULES ─────────────────────────────────────────────────────────────
  await db.insert(schedulesTable).values([
    { inmateId: i1.id, facilityId: f1.id, name: "Standard Call Window", daysOfWeek: ["monday", "tuesday", "wednesday", "thursday", "friday"], startTime: "09:00", endTime: "21:00", maxDurationMinutes: 60, isActive: true },
    { inmateId: i1.id, facilityId: f1.id, name: "Weekend Extended Window", daysOfWeek: ["saturday", "sunday"], startTime: "10:00", endTime: "20:00", maxDurationMinutes: 90, isActive: true },
    { inmateId: i2.id, facilityId: f1.id, name: "Restricted Call Schedule", daysOfWeek: ["tuesday", "thursday", "saturday"], startTime: "14:00", endTime: "15:00", maxDurationMinutes: 15, isActive: true },
    { inmateId: i4.id, facilityId: f2.id, name: "Daily Call Window", daysOfWeek: ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"], startTime: "08:00", endTime: "22:00", maxDurationMinutes: 45, isActive: true },
    { inmateId: i6.id, facilityId: f3.id, name: "Court-Ordered Schedule", daysOfWeek: ["monday", "wednesday", "friday"], startTime: "10:00", endTime: "11:00", maxDurationMinutes: 60, isActive: true },
    { inmateId: i7.id, facilityId: f1.id, name: "Standard Minimum Security Window", daysOfWeek: ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"], startTime: "09:00", endTime: "21:00", maxDurationMinutes: 60, isActive: true },
  ]);

  console.log("Seed complete.");
  process.exit(0);
}

seed().catch((e) => { console.error(e); process.exit(1); });
