type DeepStringify<T> = T extends Date
  ? string
  : T extends object
  ? { [K in keyof T]: DeepStringify<T[K]> }
  : T extends number
  ? string
  : T;

export function coerceForDrizzle<T extends Record<string, unknown>>(data: T): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(data)) {
    if (v === undefined || v === null) {
      out[k] = v;
    } else if (v instanceof Date) {
      out[k] = v.toISOString();
    } else {
      out[k] = v;
    }
  }
  return out;
}

export function numericStr(v: number | string | null | undefined): string | null | undefined {
  if (v === undefined) return undefined;
  if (v === null) return null;
  return String(v);
}
