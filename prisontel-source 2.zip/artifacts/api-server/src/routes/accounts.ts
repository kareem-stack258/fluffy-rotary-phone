import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, accountsTable, transactionsTable } from "@workspace/db";
import {
  ListAccountsQueryParams,
  ListAccountsResponse,
  CreateAccountBody,
  GetAccountParams,
  GetAccountResponse,
  UpdateAccountParams,
  UpdateAccountBody,
  UpdateAccountResponse,
  DepositToAccountParams,
  DepositToAccountBody,
  DepositToAccountResponse,
  FreezeAccountParams,
  FreezeAccountResponse,
  UnfreezeAccountParams,
  UnfreezeAccountResponse,
  ListAccountTransactionsParams,
  ListAccountTransactionsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/accounts", async (req, res): Promise<void> => {
  const qp = ListAccountsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { facilityId, frozen } = qp.data;
  const conditions: ReturnType<typeof eq>[] = [];
  if (facilityId) conditions.push(eq(accountsTable.facilityId, facilityId));
  if (frozen !== undefined) conditions.push(eq(accountsTable.status, frozen ? "frozen" : "active"));

  const accounts = await db.select().from(accountsTable).where(conditions.length ? and(...conditions) : undefined);
  res.json(ListAccountsResponse.parse(accounts));
});

router.post("/accounts", async (req, res): Promise<void> => {
  const parsed = CreateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { initialBalance, ...rest } = parsed.data as typeof parsed.data & { initialBalance?: number };
  const [account] = await db.insert(accountsTable).values({ ...rest, balance: String(initialBalance ?? 0) }).returning();
  res.status(201).json(GetAccountResponse.parse(account));
});

router.get("/accounts/:id", async (req, res): Promise<void> => {
  const params = GetAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.id, params.data.id));
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json(GetAccountResponse.parse(account));
});

router.patch("/accounts/:id", async (req, res): Promise<void> => {
  const params = UpdateAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [account] = await db.update(accountsTable).set(parsed.data).where(eq(accountsTable.id, params.data.id)).returning();
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json(UpdateAccountResponse.parse(account));
});

router.post("/accounts/:id/deposit", async (req, res): Promise<void> => {
  const params = DepositToAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = DepositToAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.id, params.data.id));
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  const newBalance = Number(account.balance) + parsed.data.amount;
  const [updated] = await db.update(accountsTable)
    .set({
      balance: String(newBalance),
      totalDeposited: String(Number(account.totalDeposited) + parsed.data.amount),
      lastDepositAmount: String(parsed.data.amount),
      lastDepositAt: new Date(),
      lastActivityAt: new Date(),
    })
    .where(eq(accountsTable.id, params.data.id)).returning();
  await db.insert(transactionsTable).values({
    accountId: params.data.id,
    type: "deposit",
    amount: String(parsed.data.amount),
    balanceBefore: String(Number(account.balance)),
    balanceAfter: String(newBalance),
    description: `Deposit via ${parsed.data.paymentMethod}`,
    paymentMethod: parsed.data.paymentMethod as "cash" | "credit_card" | "money_order" | "kiosk" | "online",
    reference: parsed.data.reference ?? null,
  });
  res.json(DepositToAccountResponse.parse(updated));
});

router.patch("/accounts/:id/freeze", async (req, res): Promise<void> => {
  const params = FreezeAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [account] = await db.update(accountsTable).set({ status: "frozen" }).where(eq(accountsTable.id, params.data.id)).returning();
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json(FreezeAccountResponse.parse(account));
});

router.patch("/accounts/:id/unfreeze", async (req, res): Promise<void> => {
  const params = UnfreezeAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [account] = await db.update(accountsTable).set({ status: "active" }).where(eq(accountsTable.id, params.data.id)).returning();
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json(UnfreezeAccountResponse.parse(account));
});

router.get("/accounts/:id/transactions", async (req, res): Promise<void> => {
  const params = ListAccountTransactionsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const txns = await db.select().from(transactionsTable)
    .where(eq(transactionsTable.accountId, params.data.id))
    .orderBy(transactionsTable.createdAt);
  res.json(ListAccountTransactionsResponse.parse(txns));
});

export default router;
