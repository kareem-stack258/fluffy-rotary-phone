import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, alertsTable } from "@workspace/db";
import {
  ListAlertsQueryParams,
  ListAlertsResponse,
  CreateAlertBody,
  GetAlertParams,
  GetAlertResponse,
  UpdateAlertParams,
  UpdateAlertBody,
  UpdateAlertResponse,
  ResolveAlertParams,
  ResolveAlertBody,
  ResolveAlertResponse,
  DismissAlertParams,
  DismissAlertResponse,
  GetAlertSummaryQueryParams,
  GetAlertSummaryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/alerts", async (req, res): Promise<void> => {
  const qp = ListAlertsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { facilityId, severity, status, type, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof eq>[] = [];
  if (facilityId) conditions.push(eq(alertsTable.facilityId, facilityId));
  if (severity) conditions.push(eq(alertsTable.severity, severity as "low" | "medium" | "high" | "critical"));
  if (status) conditions.push(eq(alertsTable.status, status as "open" | "investigating" | "resolved" | "dismissed"));
  if (type) conditions.push(eq(alertsTable.type, type as "flagged_call" | "flagged_message" | "unauthorized_contact" | "suspicious_activity" | "policy_violation" | "account_fraud"));

  const whereClause = conditions.length ? and(...conditions) : undefined;
  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(alertsTable).where(whereClause);
  const data = await db.select().from(alertsTable).where(whereClause).orderBy(alertsTable.createdAt).limit(limit).offset(offset);

  res.json(ListAlertsResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/alerts", async (req, res): Promise<void> => {
  const parsed = CreateAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [alert] = await db.insert(alertsTable).values(parsed.data).returning();
  res.status(201).json(GetAlertResponse.parse(alert));
});

router.get("/alerts/summary", async (req, res): Promise<void> => {
  const qp = GetAlertSummaryQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const conditions: ReturnType<typeof eq>[] = [];
  if (qp.data.facilityId) conditions.push(eq(alertsTable.facilityId, qp.data.facilityId));
  const whereClause = conditions.length ? and(...conditions) : undefined;

  const [counts] = await db.select({
    total: sql<number>`count(*)`,
    openCritical: sql<number>`count(*) filter (where status = 'open' and severity = 'critical')`,
    low: sql<number>`count(*) filter (where severity = 'low')`,
    medium: sql<number>`count(*) filter (where severity = 'medium')`,
    high: sql<number>`count(*) filter (where severity = 'high')`,
    critical: sql<number>`count(*) filter (where severity = 'critical')`,
    statusOpen: sql<number>`count(*) filter (where status = 'open')`,
    statusInvestigating: sql<number>`count(*) filter (where status = 'investigating')`,
    statusResolved: sql<number>`count(*) filter (where status = 'resolved')`,
    statusDismissed: sql<number>`count(*) filter (where status = 'dismissed')`,
  }).from(alertsTable).where(whereClause);

  res.json(GetAlertSummaryResponse.parse({
    total: Number(counts.total),
    openCritical: Number(counts.openCritical),
    bySeverity: {
      low: Number(counts.low),
      medium: Number(counts.medium),
      high: Number(counts.high),
      critical: Number(counts.critical),
    },
    byStatus: {
      open: Number(counts.statusOpen),
      investigating: Number(counts.statusInvestigating),
      resolved: Number(counts.statusResolved),
      dismissed: Number(counts.statusDismissed),
    },
    byType: {},
  }));
});

router.get("/alerts/:id", async (req, res): Promise<void> => {
  const params = GetAlertParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [alert] = await db.select().from(alertsTable).where(eq(alertsTable.id, params.data.id));
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  res.json(GetAlertResponse.parse(alert));
});

router.patch("/alerts/:id", async (req, res): Promise<void> => {
  const params = UpdateAlertParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [alert] = await db.update(alertsTable).set(parsed.data).where(eq(alertsTable.id, params.data.id)).returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  res.json(UpdateAlertResponse.parse(alert));
});

router.patch("/alerts/:id/resolve", async (req, res): Promise<void> => {
  const params = ResolveAlertParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = ResolveAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [alert] = await db.update(alertsTable)
    .set({ status: "resolved", resolutionNotes: parsed.data.notes, resolvedBy: parsed.data.resolvedBy ?? null, resolvedAt: new Date() })
    .where(eq(alertsTable.id, params.data.id)).returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  res.json(ResolveAlertResponse.parse(alert));
});

router.patch("/alerts/:id/dismiss", async (req, res): Promise<void> => {
  const params = DismissAlertParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [alert] = await db.update(alertsTable)
    .set({ status: "dismissed" })
    .where(eq(alertsTable.id, params.data.id)).returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  res.json(DismissAlertResponse.parse(alert));
});

export default router;
