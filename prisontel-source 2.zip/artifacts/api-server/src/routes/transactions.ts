import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, transactionsTable } from "@workspace/db";
import {
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  CreateTransactionBody,
  GetTransactionParams,
  GetTransactionResponse,
  GetTransactionSummaryQueryParams,
  GetTransactionSummaryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/transactions", async (req, res): Promise<void> => {
  const qp = ListTransactionsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { accountId, type, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof eq>[] = [];
  if (accountId) conditions.push(eq(transactionsTable.accountId, accountId));
  if (type) conditions.push(eq(transactionsTable.type, type as "deposit" | "call_charge" | "message_charge" | "refund" | "adjustment" | "fee"));

  const whereClause = conditions.length ? and(...conditions) : undefined;
  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(transactionsTable).where(whereClause);
  const data = await db.select().from(transactionsTable).where(whereClause).orderBy(transactionsTable.createdAt).limit(limit).offset(offset);

  res.json(ListTransactionsResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/transactions", async (req, res): Promise<void> => {
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [txn] = await db.insert(transactionsTable).values({
    ...parsed.data,
    amount: String(parsed.data.amount),
    balanceBefore: "0",
    balanceAfter: "0",
  }).returning();
  res.status(201).json(GetTransactionResponse.parse(txn));
});

router.get("/transactions/summary", async (req, res): Promise<void> => {
  const qp = GetTransactionSummaryQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const [stats] = await db.select({
    totalDeposits: sql<number>`coalesce(sum(amount) filter (where type = 'deposit'), 0)`,
    totalCallCharges: sql<number>`coalesce(sum(amount) filter (where type = 'call_charge'), 0)`,
    totalMessageCharges: sql<number>`coalesce(sum(amount) filter (where type = 'message_charge'), 0)`,
    totalRefunds: sql<number>`coalesce(sum(amount) filter (where type = 'refund'), 0)`,
    totalFees: sql<number>`coalesce(sum(amount) filter (where type = 'fee'), 0)`,
    transactionCount: sql<number>`count(*)`,
    avgDeposit: sql<number>`coalesce(avg(amount) filter (where type = 'deposit'), 0)`,
  }).from(transactionsTable);

  const totalDeposits = Number(stats.totalDeposits);
  const totalCallCharges = Number(stats.totalCallCharges);
  const totalMessageCharges = Number(stats.totalMessageCharges);
  const totalRefunds = Number(stats.totalRefunds);
  const totalFees = Number(stats.totalFees);

  res.json(GetTransactionSummaryResponse.parse({
    totalDeposits,
    totalCallCharges,
    totalMessageCharges,
    totalRefunds,
    totalFees,
    netRevenue: totalCallCharges + totalMessageCharges + totalFees - totalRefunds,
    transactionCount: Number(stats.transactionCount),
    averageDepositAmount: Number(stats.avgDeposit),
  }));
});

router.get("/transactions/:id", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [txn] = await db.select().from(transactionsTable).where(eq(transactionsTable.id, params.data.id));
  if (!txn) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json(GetTransactionResponse.parse(txn));
});

export default router;
