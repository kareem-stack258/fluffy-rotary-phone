import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, recordingsTable } from "@workspace/db";
import {
  ListRecordingsQueryParams,
  ListRecordingsResponse,
  CreateRecordingBody,
  GetRecordingParams,
  GetRecordingResponse,
  UpdateRecordingParams,
  UpdateRecordingBody,
  UpdateRecordingResponse,
  DeleteRecordingParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/recordings", async (req, res): Promise<void> => {
  const qp = ListRecordingsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { callId, inmateId, reviewed, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof eq>[] = [];
  if (callId) conditions.push(eq(recordingsTable.callId, callId));
  if (inmateId) conditions.push(eq(recordingsTable.inmateId, inmateId));
  if (reviewed !== undefined) conditions.push(eq(recordingsTable.isReviewed, reviewed));

  const whereClause = conditions.length ? and(...conditions) : undefined;
  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(recordingsTable).where(whereClause);
  const data = await db.select().from(recordingsTable).where(whereClause).orderBy(recordingsTable.createdAt).limit(limit).offset(offset);

  res.json(ListRecordingsResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/recordings", async (req, res): Promise<void> => {
  const parsed = CreateRecordingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [rec] = await db.insert(recordingsTable).values(parsed.data).returning();
  res.status(201).json(GetRecordingResponse.parse(rec));
});

router.get("/recordings/:id", async (req, res): Promise<void> => {
  const params = GetRecordingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [rec] = await db.select().from(recordingsTable).where(eq(recordingsTable.id, params.data.id));
  if (!rec) {
    res.status(404).json({ error: "Recording not found" });
    return;
  }
  res.json(GetRecordingResponse.parse(rec));
});

router.patch("/recordings/:id", async (req, res): Promise<void> => {
  const params = UpdateRecordingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateRecordingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.isReviewed) updateData.reviewedAt = new Date();
  const [rec] = await db.update(recordingsTable).set(updateData).where(eq(recordingsTable.id, params.data.id)).returning();
  if (!rec) {
    res.status(404).json({ error: "Recording not found" });
    return;
  }
  res.json(UpdateRecordingResponse.parse(rec));
});

router.delete("/recordings/:id", async (req, res): Promise<void> => {
  const params = DeleteRecordingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [rec] = await db.delete(recordingsTable).where(eq(recordingsTable.id, params.data.id)).returning();
  if (!rec) {
    res.status(404).json({ error: "Recording not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
