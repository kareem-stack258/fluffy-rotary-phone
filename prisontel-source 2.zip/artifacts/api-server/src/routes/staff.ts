import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, staffTable } from "@workspace/db";
import { coerceForDrizzle } from "../lib/coerce";
import {
  ListStaffQueryParams,
  ListStaffResponse,
  CreateStaffBody,
  GetStaffParams,
  GetStaffResponse,
  UpdateStaffParams,
  UpdateStaffBody,
  UpdateStaffResponse,
  DeleteStaffParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/staff", async (req, res): Promise<void> => {
  const qp = ListStaffQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { facilityId, role, active } = qp.data;
  const conditions: ReturnType<typeof eq>[] = [];
  if (facilityId) conditions.push(eq(staffTable.facilityId, facilityId));
  if (role) conditions.push(eq(staffTable.role, role as "admin" | "supervisor" | "officer" | "analyst" | "operator"));
  if (active !== undefined) conditions.push(eq(staffTable.status, active ? "active" : "inactive"));

  const staff = await db.select().from(staffTable).where(conditions.length ? and(...conditions) : undefined).orderBy(staffTable.lastName);
  res.json(ListStaffResponse.parse(staff));
});

router.post("/staff", async (req, res): Promise<void> => {
  const parsed = CreateStaffBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [s] = await db.insert(staffTable).values(coerceForDrizzle(parsed.data) as any).returning();
  res.status(201).json(GetStaffResponse.parse(s));
});

router.get("/staff/:id", async (req, res): Promise<void> => {
  const params = GetStaffParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [s] = await db.select().from(staffTable).where(eq(staffTable.id, params.data.id));
  if (!s) {
    res.status(404).json({ error: "Staff not found" });
    return;
  }
  res.json(GetStaffResponse.parse(s));
});

router.patch("/staff/:id", async (req, res): Promise<void> => {
  const params = UpdateStaffParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateStaffBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [s] = await db.update(staffTable).set(coerceForDrizzle(parsed.data) as any).where(eq(staffTable.id, params.data.id)).returning();
  if (!s) {
    res.status(404).json({ error: "Staff not found" });
    return;
  }
  res.json(UpdateStaffResponse.parse(s));
});

router.delete("/staff/:id", async (req, res): Promise<void> => {
  const params = DeleteStaffParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [s] = await db.delete(staffTable).where(eq(staffTable.id, params.data.id)).returning();
  if (!s) {
    res.status(404).json({ error: "Staff not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
