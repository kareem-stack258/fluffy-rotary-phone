import { Router, type IRouter } from "express";
import { eq, ilike, and } from "drizzle-orm";
import { db, contactsTable } from "@workspace/db";
import {
  ListContactsQueryParams,
  ListContactsResponse,
  CreateContactBody,
  GetContactParams,
  GetContactResponse,
  UpdateContactParams,
  UpdateContactBody,
  UpdateContactResponse,
  DeleteContactParams,
  ApproveContactParams,
  ApproveContactResponse,
  RejectContactParams,
  RejectContactBody,
  RejectContactResponse,
  RevokeContactParams,
  RevokeContactBody,
  RevokeContactResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/contacts", async (req, res): Promise<void> => {
  const qp = ListContactsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { inmateId, status, search } = qp.data;
  const conditions = [];
  if (inmateId) conditions.push(eq(contactsTable.inmateId, inmateId));
  if (status) conditions.push(eq(contactsTable.status, status as "pending" | "approved" | "rejected" | "revoked"));
  if (search) conditions.push(ilike(contactsTable.firstName, `%${search}%`));

  const contacts = await db.select().from(contactsTable).where(conditions.length ? and(...conditions) : undefined).orderBy(contactsTable.createdAt);
  res.json(ListContactsResponse.parse(contacts));
});

router.post("/contacts", async (req, res): Promise<void> => {
  const parsed = CreateContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [contact] = await db.insert(contactsTable).values(parsed.data).returning();
  res.status(201).json(GetContactResponse.parse(contact));
});

router.get("/contacts/:id", async (req, res): Promise<void> => {
  const params = GetContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [contact] = await db.select().from(contactsTable).where(eq(contactsTable.id, params.data.id));
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.json(GetContactResponse.parse(contact));
});

router.patch("/contacts/:id", async (req, res): Promise<void> => {
  const params = UpdateContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [contact] = await db.update(contactsTable).set(parsed.data).where(eq(contactsTable.id, params.data.id)).returning();
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.json(UpdateContactResponse.parse(contact));
});

router.delete("/contacts/:id", async (req, res): Promise<void> => {
  const params = DeleteContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [contact] = await db.delete(contactsTable).where(eq(contactsTable.id, params.data.id)).returning();
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.sendStatus(204);
});

router.patch("/contacts/:id/approve", async (req, res): Promise<void> => {
  const params = ApproveContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [contact] = await db.update(contactsTable)
    .set({ status: "approved", approvedAt: new Date() })
    .where(eq(contactsTable.id, params.data.id))
    .returning();
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.json(ApproveContactResponse.parse(contact));
});

router.patch("/contacts/:id/reject", async (req, res): Promise<void> => {
  const params = RejectContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = RejectContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [contact] = await db.update(contactsTable)
    .set({ status: "rejected", rejectionReason: parsed.data.reason })
    .where(eq(contactsTable.id, params.data.id))
    .returning();
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.json(RejectContactResponse.parse(contact));
});

router.patch("/contacts/:id/revoke", async (req, res): Promise<void> => {
  const params = RevokeContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = RevokeContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [contact] = await db.update(contactsTable)
    .set({ status: "revoked", revocationReason: parsed.data.reason })
    .where(eq(contactsTable.id, params.data.id))
    .returning();
  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.json(RevokeContactResponse.parse(contact));
});

export default router;
