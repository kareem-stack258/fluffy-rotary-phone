import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, facilitiesTable, inmatesTable, callsTable, alertsTable, messagesTable, accountsTable, transactionsTable } from "@workspace/db";
import {
  GetDashboardReportQueryParams,
  GetDashboardReportResponse,
  GetCallVolumeReportQueryParams,
  GetCallVolumeReportResponse,
  GetRevenueReportQueryParams,
  GetRevenueReportResponse,
  GetTopCallersQueryParams,
  GetTopCallersResponse,
  GetFlaggedSummaryQueryParams,
  GetFlaggedSummaryResponse,
  GetInmateCommunicationReportQueryParams,
  GetInmateCommunicationReportResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/reports/dashboard", async (req, res): Promise<void> => {
  const qp = GetDashboardReportQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString();
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();

  const conditions: ReturnType<typeof eq>[] = [];
  const facilityId = qp.data.facilityId;

  const facilityCondition = facilityId ? eq(facilitiesTable.id, facilityId) : undefined;

  const [facilityCount] = await db.select({ count: sql<number>`count(*)` }).from(facilitiesTable).where(facilityCondition);
  const [inmateStats] = await db.select({
    total: sql<number>`count(*)`,
    active: sql<number>`count(*) filter (where status = 'active')`,
  }).from(inmatesTable).where(facilityId ? eq(inmatesTable.facilityId, facilityId) : undefined);

  const callWhere = facilityId ? eq(callsTable.facilityId, facilityId) : undefined;
  const [callsToday] = await db.select({
    total: sql<number>`count(*)`,
    active: sql<number>`count(*) filter (where status = 'active')`,
    thisWeek: sql<number>`count(*) filter (where started_at >= ${weekAgo})`,
  }).from(callsTable).where(facilityId ? sql`facility_id = ${facilityId} and started_at >= ${todayStr}` : sql`started_at >= ${todayStr}`);

  const [alertStats] = await db.select({
    open: sql<number>`count(*) filter (where status in ('open','investigating'))`,
    critical: sql<number>`count(*) filter (where status = 'open' and severity = 'critical')`,
  }).from(alertsTable).where(facilityId ? eq(alertsTable.facilityId, facilityId) : undefined);

  const [msgStats] = await db.select({
    pending: sql<number>`count(*) filter (where status = 'pending')`,
  }).from(messagesTable).where(facilityId ? eq(messagesTable.facilityId, facilityId) : undefined);

  const [accountStats] = await db.select({
    lowBalance: sql<number>`count(*) filter (where balance < 5.00 and status = 'active')`,
    frozen: sql<number>`count(*) filter (where status = 'frozen')`,
  }).from(accountsTable).where(facilityId ? eq(accountsTable.facilityId, facilityId) : undefined);

  const [revStats] = await db.select({
    total: sql<number>`coalesce(sum(cost_amount),0)`,
  }).from(callsTable).where(facilityId ? eq(callsTable.facilityId, facilityId) : undefined);

  const [monthRev] = await db.select({
    total: sql<number>`coalesce(sum(amount) filter (where type in ('call_charge','message_charge','fee')),0)`,
  }).from(transactionsTable).where(sql`created_at >= ${monthStart}`);

  const pendingContacts = await db.select({ count: sql<number>`count(*)` }).from(sql`contacts where status = 'pending'`);

  const recentCalls = await db.select().from(callsTable).orderBy(callsTable.startedAt).limit(5);
  const recentActivity = recentCalls.map(c => ({
    id: `call-${c.id}`,
    type: "call" as const,
    title: `Call ${c.status}`,
    description: `Inmate #${c.inmateId} — ${c.phoneNumber}`,
    timestamp: c.startedAt.toISOString(),
    metadata: {},
  }));

  res.json(GetDashboardReportResponse.parse({
    totalFacilities: Number(facilityCount.count),
    totalInmates: Number(inmateStats.total),
    activeInmates: Number(inmateStats.active),
    totalCallsToday: Number(callsToday.total),
    activeCallsNow: Number(callsToday.active),
    totalCallsThisWeek: Number(callsToday.thisWeek),
    openAlerts: Number(alertStats.open),
    criticalAlerts: Number(alertStats.critical),
    pendingApprovals: Number((pendingContacts[0] as { count: number })?.count ?? 0),
    pendingMessages: Number(msgStats.pending),
    totalRevenue: Number(revStats.total),
    revenueThisMonth: Number(monthRev.total),
    lowBalanceAccounts: Number(accountStats.lowBalance),
    frozenAccounts: Number(accountStats.frozen),
    recentActivity,
  }));
});

router.get("/reports/call-volume", async (req, res): Promise<void> => {
  const qp = GetCallVolumeReportQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const dateFrom = qp.data.dateFrom ?? new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const dateTo = qp.data.dateTo ?? new Date().toISOString().split("T")[0];

  const conditions: string[] = [`started_at >= '${dateFrom}' and started_at <= '${dateTo}'`];
  if (qp.data.facilityId) conditions.push(`facility_id = ${qp.data.facilityId}`);

  const rows = await db.execute(sql`
    select
      date(started_at) as date,
      count(*) as total_calls,
      count(*) filter (where status = 'completed') as completed_calls,
      count(*) filter (where is_flagged = true) as flagged_calls,
      count(*) filter (where status = 'blocked') as blocked_calls,
      coalesce(sum(duration_seconds),0)/60.0 as total_minutes,
      coalesce(avg(duration_seconds),0) as avg_duration
    from calls
    where started_at >= ${dateFrom} and started_at <= ${dateTo}
    group by date(started_at)
    order by date(started_at)
  `);

  const points = (rows.rows as Record<string, unknown>[]).map((r) => ({
    date: String(r.date),
    totalCalls: Number(r.total_calls),
    completedCalls: Number(r.completed_calls),
    flaggedCalls: Number(r.flagged_calls),
    blockedCalls: Number(r.blocked_calls),
    totalMinutes: Number(r.total_minutes),
    averageDurationSeconds: Number(r.avg_duration),
  }));

  res.json(GetCallVolumeReportResponse.parse(points));
});

router.get("/reports/revenue", async (req, res): Promise<void> => {
  const qp = GetRevenueReportQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const dateFrom = qp.data.dateFrom ?? new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  const dateTo = qp.data.dateTo ?? new Date().toISOString().split("T")[0];

  const rows = await db.execute(sql`
    select
      date(created_at) as date,
      coalesce(sum(amount) filter (where type in ('call_charge','message_charge','fee')),0) as total_revenue,
      coalesce(sum(amount) filter (where type = 'call_charge'),0) as call_revenue,
      coalesce(sum(amount) filter (where type = 'message_charge'),0) as message_revenue,
      coalesce(sum(amount) filter (where type = 'deposit'),0) as total_deposits,
      count(*) as transaction_count
    from transactions
    where created_at >= ${dateFrom} and created_at <= ${dateTo}
    group by date(created_at)
    order by date(created_at)
  `);

  const points = (rows.rows as Record<string, unknown>[]).map((r) => ({
    date: String(r.date),
    totalRevenue: Number(r.total_revenue),
    callRevenue: Number(r.call_revenue),
    messageRevenue: Number(r.message_revenue),
    totalDeposits: Number(r.total_deposits),
    transactionCount: Number(r.transaction_count),
  }));

  res.json(GetRevenueReportResponse.parse(points));
});

router.get("/reports/top-callers", async (req, res): Promise<void> => {
  const qp = GetTopCallersQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const limit = qp.data.limit ?? 10;

  const rows = await db.execute(sql`
    select
      i.id as inmate_id,
      i.inmate_number,
      i.first_name,
      i.last_name,
      f.name as facility_name,
      count(c.id) as total_calls,
      coalesce(sum(c.duration_seconds),0)/60.0 as total_minutes,
      coalesce(sum(c.cost_amount),0) as total_spent,
      count(c.id) filter (where c.is_flagged = true) as flagged_calls
    from inmates i
    left join calls c on c.inmate_id = i.id
    left join facilities f on f.id = i.facility_id
    group by i.id, i.inmate_number, i.first_name, i.last_name, f.name
    order by total_calls desc
    limit ${limit}
  `);

  const callers = (rows.rows as Record<string, unknown>[]).map((r) => ({
    inmateId: Number(r.inmate_id),
    inmateNumber: String(r.inmate_number),
    firstName: String(r.first_name),
    lastName: String(r.last_name),
    facilityName: String(r.facility_name ?? ""),
    totalCalls: Number(r.total_calls),
    totalMinutes: Number(r.total_minutes),
    totalSpent: Number(r.total_spent),
    flaggedCalls: Number(r.flagged_calls),
  }));

  res.json(GetTopCallersResponse.parse(callers));
});

router.get("/reports/flagged-summary", async (req, res): Promise<void> => {
  const qp = GetFlaggedSummaryQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const [callFlags] = await db.select({ count: sql<number>`count(*) filter (where is_flagged = true)` }).from(callsTable);
  const [msgFlags] = await db.select({ count: sql<number>`count(*) filter (where is_flagged = true)` }).from(messagesTable);
  const [alertStats] = await db.select({
    open: sql<number>`count(*) filter (where status in ('open','investigating'))`,
    resolved: sql<number>`count(*) filter (where status = 'resolved')`,
    critical: sql<number>`count(*) filter (where status = 'open' and severity = 'critical')`,
  }).from(alertsTable);

  res.json(GetFlaggedSummaryResponse.parse({
    flaggedCalls: Number(callFlags.count),
    flaggedMessages: Number(msgFlags.count),
    openAlerts: Number(alertStats.open),
    resolvedAlerts: Number(alertStats.resolved),
    criticalAlerts: Number(alertStats.critical),
    topFlaggedInmates: [],
  }));
});

router.get("/reports/inmate-communication", async (req, res): Promise<void> => {
  const qp = GetInmateCommunicationReportQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const inmateId = qp.data.inmateId!;

  const [callStats] = await db.select({
    total: sql<number>`count(*)`,
    totalSecs: sql<number>`coalesce(sum(duration_seconds),0)`,
    totalCost: sql<number>`coalesce(sum(cost_amount),0)`,
    flagged: sql<number>`count(*) filter (where is_flagged = true)`,
  }).from(callsTable).where(eq(callsTable.inmateId, inmateId));

  const [msgStats] = await db.select({
    total: sql<number>`count(*)`,
    flagged: sql<number>`count(*) filter (where is_flagged = true)`,
  }).from(messagesTable).where(eq(messagesTable.inmateId, inmateId));

  const [contactCount] = await db.select({ count: sql<number>`count(*)` }).from(sql`contacts where inmate_id = ${inmateId} and status = 'approved'`);

  res.json(GetInmateCommunicationReportResponse.parse({
    inmateId,
    totalCalls: Number(callStats.total),
    totalMessages: Number(msgStats.total),
    totalMinutes: Number(callStats.totalSecs) / 60,
    totalSpent: Number(callStats.totalCost),
    contactCount: Number((contactCount as { count: number })?.count ?? 0),
    flaggedCallCount: Number(callStats.flagged),
    flaggedMessageCount: Number(msgStats.flagged),
    callsByDay: [],
    topContacts: [],
  }));
});

export default router;
