import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, restrictionsTable } from "@workspace/db";
import {
  ListRestrictionsQueryParams,
  ListRestrictionsResponse,
  CreateRestrictionBody,
  GetRestrictionParams,
  GetRestrictionResponse,
  UpdateRestrictionParams,
  UpdateRestrictionBody,
  UpdateRestrictionResponse,
  DeleteRestrictionParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/restrictions", async (req, res): Promise<void> => {
  const qp = ListRestrictionsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { inmateId, type, active } = qp.data;
  const conditions: ReturnType<typeof eq>[] = [];
  if (inmateId) conditions.push(eq(restrictionsTable.inmateId, inmateId));
  if (type) conditions.push(eq(restrictionsTable.type, type as "blocked_number" | "time_limit" | "total_ban" | "schedule_only"));
  if (active !== undefined) conditions.push(eq(restrictionsTable.isActive, active));

  const restrictions = await db.select().from(restrictionsTable).where(conditions.length ? and(...conditions) : undefined);
  res.json(ListRestrictionsResponse.parse(restrictions));
});

router.post("/restrictions", async (req, res): Promise<void> => {
  const parsed = CreateRestrictionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [r] = await db.insert(restrictionsTable).values(parsed.data).returning();
  res.status(201).json(GetRestrictionResponse.parse(r));
});

router.get("/restrictions/:id", async (req, res): Promise<void> => {
  const params = GetRestrictionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [r] = await db.select().from(restrictionsTable).where(eq(restrictionsTable.id, params.data.id));
  if (!r) {
    res.status(404).json({ error: "Restriction not found" });
    return;
  }
  res.json(GetRestrictionResponse.parse(r));
});

router.patch("/restrictions/:id", async (req, res): Promise<void> => {
  const params = UpdateRestrictionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateRestrictionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [r] = await db.update(restrictionsTable).set(parsed.data).where(eq(restrictionsTable.id, params.data.id)).returning();
  if (!r) {
    res.status(404).json({ error: "Restriction not found" });
    return;
  }
  res.json(UpdateRestrictionResponse.parse(r));
});

router.delete("/restrictions/:id", async (req, res): Promise<void> => {
  const params = DeleteRestrictionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [r] = await db.delete(restrictionsTable).where(eq(restrictionsTable.id, params.data.id)).returning();
  if (!r) {
    res.status(404).json({ error: "Restriction not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
