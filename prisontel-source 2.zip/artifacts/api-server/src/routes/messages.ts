import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, messagesTable } from "@workspace/db";
import {
  ListMessagesQueryParams,
  ListMessagesResponse,
  CreateMessageBody,
  GetMessageParams,
  GetMessageResponse,
  DeleteMessageParams,
  ApproveMessageParams,
  ApproveMessageResponse,
  RejectMessageParams,
  RejectMessageBody,
  RejectMessageResponse,
  FlagMessageParams,
  FlagMessageBody,
  FlagMessageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/messages", async (req, res): Promise<void> => {
  const qp = ListMessagesQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { inmateId, status, direction, flagged, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof eq>[] = [];
  if (inmateId) conditions.push(eq(messagesTable.inmateId, inmateId));
  if (status) conditions.push(eq(messagesTable.status, status as "pending" | "approved" | "delivered" | "rejected" | "flagged"));
  if (direction) conditions.push(eq(messagesTable.direction, direction as "inbound" | "outbound"));
  if (flagged !== undefined) conditions.push(eq(messagesTable.isFlagged, flagged));

  const whereClause = conditions.length ? and(...conditions) : undefined;
  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(messagesTable).where(whereClause);
  const data = await db.select().from(messagesTable).where(whereClause).orderBy(messagesTable.createdAt).limit(limit).offset(offset);

  res.json(ListMessagesResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/messages", async (req, res): Promise<void> => {
  const parsed = CreateMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const wordCount = parsed.data.body.split(/\s+/).length;
  const [msg] = await db.insert(messagesTable).values({ ...parsed.data, wordCount }).returning();
  res.status(201).json(GetMessageResponse.parse(msg));
});

router.get("/messages/:id", async (req, res): Promise<void> => {
  const params = GetMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [msg] = await db.select().from(messagesTable).where(eq(messagesTable.id, params.data.id));
  if (!msg) {
    res.status(404).json({ error: "Message not found" });
    return;
  }
  res.json(GetMessageResponse.parse(msg));
});

router.delete("/messages/:id", async (req, res): Promise<void> => {
  const params = DeleteMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [msg] = await db.delete(messagesTable).where(eq(messagesTable.id, params.data.id)).returning();
  if (!msg) {
    res.status(404).json({ error: "Message not found" });
    return;
  }
  res.sendStatus(204);
});

router.patch("/messages/:id/approve", async (req, res): Promise<void> => {
  const params = ApproveMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [msg] = await db.update(messagesTable)
    .set({ status: "approved", reviewedAt: new Date() })
    .where(eq(messagesTable.id, params.data.id)).returning();
  if (!msg) {
    res.status(404).json({ error: "Message not found" });
    return;
  }
  res.json(ApproveMessageResponse.parse(msg));
});

router.patch("/messages/:id/reject", async (req, res): Promise<void> => {
  const params = RejectMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = RejectMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [msg] = await db.update(messagesTable)
    .set({ status: "rejected", rejectionReason: parsed.data.reason, reviewedAt: new Date() })
    .where(eq(messagesTable.id, params.data.id)).returning();
  if (!msg) {
    res.status(404).json({ error: "Message not found" });
    return;
  }
  res.json(RejectMessageResponse.parse(msg));
});

router.patch("/messages/:id/flag", async (req, res): Promise<void> => {
  const params = FlagMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = FlagMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [msg] = await db.update(messagesTable)
    .set({ isFlagged: true, flagReason: parsed.data.reason, status: "flagged" })
    .where(eq(messagesTable.id, params.data.id)).returning();
  if (!msg) {
    res.status(404).json({ error: "Message not found" });
    return;
  }
  res.json(FlagMessageResponse.parse(msg));
});

export default router;
