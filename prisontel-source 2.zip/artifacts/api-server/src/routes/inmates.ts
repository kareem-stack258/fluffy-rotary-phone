import { Router, type IRouter } from "express";
import { eq, ilike, or, and, sql } from "drizzle-orm";
import { db, inmatesTable, callsTable, contactsTable, messagesTable, accountsTable, restrictionsTable } from "@workspace/db";
import { coerceForDrizzle } from "../lib/coerce";
import {
  ListInmatesQueryParams,
  ListInmatesResponse,
  CreateInmateBody,
  GetInmateParams,
  GetInmateResponse,
  UpdateInmateParams,
  UpdateInmateBody,
  UpdateInmateResponse,
  DeleteInmateParams,
  ListInmateCallsParams,
  ListInmateCallsResponse,
  GetInmateContactsParams,
  GetInmateContactsResponse,
  ListInmateMessagesParams,
  ListInmateMessagesResponse,
  GetInmateAccountParams,
  GetInmateAccountResponse,
  GetInmateActivityParams,
  GetInmateActivityResponse,
  GetInmateRestrictionsParams,
  GetInmateRestrictionsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/inmates", async (req, res): Promise<void> => {
  const qp = ListInmatesQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { facilityId, status, search, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions = [];
  if (facilityId) conditions.push(eq(inmatesTable.facilityId, facilityId));
  if (status) conditions.push(eq(inmatesTable.status, status as "active" | "transferred" | "released" | "deceased"));
  if (search) conditions.push(or(
    ilike(inmatesTable.firstName, `%${search}%`),
    ilike(inmatesTable.lastName, `%${search}%`),
    ilike(inmatesTable.inmateNumber, `%${search}%`),
  )!);

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(inmatesTable).where(whereClause);
  const data = await db.select().from(inmatesTable).where(whereClause).orderBy(inmatesTable.lastName).limit(limit).offset(offset);

  res.json(ListInmatesResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/inmates", async (req, res): Promise<void> => {
  const parsed = CreateInmateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [inmate] = await db.insert(inmatesTable).values(coerceForDrizzle(parsed.data) as any).returning();
  res.status(201).json(GetInmateResponse.parse(inmate));
});

router.get("/inmates/:id", async (req, res): Promise<void> => {
  const params = GetInmateParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [inmate] = await db.select().from(inmatesTable).where(eq(inmatesTable.id, params.data.id));
  if (!inmate) {
    res.status(404).json({ error: "Inmate not found" });
    return;
  }
  res.json(GetInmateResponse.parse(inmate));
});

router.patch("/inmates/:id", async (req, res): Promise<void> => {
  const params = UpdateInmateParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateInmateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [inmate] = await db.update(inmatesTable).set(coerceForDrizzle(parsed.data) as any).where(eq(inmatesTable.id, params.data.id)).returning();
  if (!inmate) {
    res.status(404).json({ error: "Inmate not found" });
    return;
  }
  res.json(UpdateInmateResponse.parse(inmate));
});

router.delete("/inmates/:id", async (req, res): Promise<void> => {
  const params = DeleteInmateParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [inmate] = await db.delete(inmatesTable).where(eq(inmatesTable.id, params.data.id)).returning();
  if (!inmate) {
    res.status(404).json({ error: "Inmate not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/inmates/:id/calls", async (req, res): Promise<void> => {
  const params = ListInmateCallsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const calls = await db.select().from(callsTable).where(eq(callsTable.inmateId, params.data.id)).orderBy(callsTable.startedAt);
  res.json(ListInmateCallsResponse.parse(calls));
});

router.get("/inmates/:id/contacts", async (req, res): Promise<void> => {
  const params = GetInmateContactsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const contacts = await db.select().from(contactsTable).where(eq(contactsTable.inmateId, params.data.id)).orderBy(contactsTable.lastName);
  res.json(GetInmateContactsResponse.parse(contacts));
});

router.get("/inmates/:id/messages", async (req, res): Promise<void> => {
  const params = ListInmateMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const msgs = await db.select().from(messagesTable).where(eq(messagesTable.inmateId, params.data.id)).orderBy(messagesTable.createdAt);
  res.json(ListInmateMessagesResponse.parse(msgs));
});

router.get("/inmates/:id/account", async (req, res): Promise<void> => {
  const params = GetInmateAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [account] = await db.select().from(accountsTable).where(eq(accountsTable.inmateId, params.data.id));
  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }
  res.json(GetInmateAccountResponse.parse(account));
});

router.get("/inmates/:id/activity", async (req, res): Promise<void> => {
  const params = GetInmateActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const inmateId = params.data.id;

  const recentCalls = await db.select().from(callsTable).where(eq(callsTable.inmateId, inmateId)).orderBy(callsTable.startedAt).limit(5);
  const recentMsgs = await db.select().from(messagesTable).where(eq(messagesTable.inmateId, inmateId)).orderBy(messagesTable.createdAt).limit(5);

  const events = [
    ...recentCalls.map(c => ({
      id: `call-${c.id}`,
      type: "call" as const,
      title: `${c.direction === "outbound" ? "Outgoing" : "Incoming"} Call`,
      description: `Call to ${c.phoneNumber} — ${c.durationSeconds ? Math.round(c.durationSeconds / 60) + "min" : "unknown duration"}`,
      timestamp: c.startedAt.toISOString(),
      metadata: { callId: c.id, status: c.status },
    })),
    ...recentMsgs.map(m => ({
      id: `msg-${m.id}`,
      type: "message" as const,
      title: `${m.direction === "outbound" ? "Outgoing" : "Incoming"} Message`,
      description: m.subject,
      timestamp: m.createdAt.toISOString(),
      metadata: { messageId: m.id, status: m.status },
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

  res.json(GetInmateActivityResponse.parse(events));
});

router.get("/inmates/:id/restrictions", async (req, res): Promise<void> => {
  const params = GetInmateRestrictionsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const restrictions = await db.select().from(restrictionsTable).where(eq(restrictionsTable.inmateId, params.data.id));
  res.json(GetInmateRestrictionsResponse.parse(restrictions));
});

export default router;
