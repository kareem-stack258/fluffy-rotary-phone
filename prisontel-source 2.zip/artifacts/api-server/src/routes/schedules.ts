import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, schedulesTable } from "@workspace/db";
import { coerceForDrizzle } from "../lib/coerce";
import {
  ListSchedulesQueryParams,
  ListSchedulesResponse,
  CreateScheduleBody,
  GetScheduleParams,
  GetScheduleResponse,
  UpdateScheduleParams,
  UpdateScheduleBody,
  UpdateScheduleResponse,
  DeleteScheduleParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/schedules", async (req, res): Promise<void> => {
  const qp = ListSchedulesQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { inmateId, facilityId, active } = qp.data;
  const conditions: ReturnType<typeof eq>[] = [];
  if (inmateId) conditions.push(eq(schedulesTable.inmateId, inmateId));
  if (facilityId) conditions.push(eq(schedulesTable.facilityId, facilityId));
  if (active !== undefined) conditions.push(eq(schedulesTable.isActive, active));

  const schedules = await db.select().from(schedulesTable).where(conditions.length ? and(...conditions) : undefined).orderBy(schedulesTable.name);
  res.json(ListSchedulesResponse.parse(schedules));
});

router.post("/schedules", async (req, res): Promise<void> => {
  const parsed = CreateScheduleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [s] = await db.insert(schedulesTable).values(coerceForDrizzle(parsed.data) as any).returning();
  res.status(201).json(GetScheduleResponse.parse(s));
});

router.get("/schedules/:id", async (req, res): Promise<void> => {
  const params = GetScheduleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [s] = await db.select().from(schedulesTable).where(eq(schedulesTable.id, params.data.id));
  if (!s) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }
  res.json(GetScheduleResponse.parse(s));
});

router.patch("/schedules/:id", async (req, res): Promise<void> => {
  const params = UpdateScheduleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateScheduleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [s] = await db.update(schedulesTable).set(coerceForDrizzle(parsed.data) as any).where(eq(schedulesTable.id, params.data.id)).returning();
  if (!s) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }
  res.json(UpdateScheduleResponse.parse(s));
});

router.delete("/schedules/:id", async (req, res): Promise<void> => {
  const params = DeleteScheduleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [s] = await db.delete(schedulesTable).where(eq(schedulesTable.id, params.data.id)).returning();
  if (!s) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
