import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, callsTable } from "@workspace/db";
import { numericStr } from "../lib/coerce";
import {
  ListCallsQueryParams,
  ListCallsResponse,
  CreateCallBody,
  GetCallParams,
  GetCallResponse,
  UpdateCallParams,
  UpdateCallBody,
  UpdateCallResponse,
  DeleteCallParams,
  FlagCallParams,
  FlagCallBody,
  FlagCallResponse,
  TerminateCallParams,
  TerminateCallResponse,
  ListActiveCallsQueryParams,
  ListActiveCallsResponse,
  GetCallStatsQueryParams,
  GetCallStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/calls", async (req, res): Promise<void> => {
  const qp = ListCallsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const { inmateId, facilityId, status, flagged, dateFrom, dateTo, page = 1, limit = 20 } = qp.data;
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof eq>[] = [];
  if (inmateId) conditions.push(eq(callsTable.inmateId, inmateId));
  if (facilityId) conditions.push(eq(callsTable.facilityId, facilityId));
  if (status) conditions.push(eq(callsTable.status, status as "scheduled" | "active" | "completed" | "failed" | "blocked" | "flagged"));
  if (flagged !== undefined) conditions.push(eq(callsTable.isFlagged, flagged));

  const whereClause = conditions.length ? and(...conditions) : undefined;

  const [{ total }] = await db.select({ total: sql<number>`count(*)` }).from(callsTable).where(whereClause);
  const data = await db.select().from(callsTable).where(whereClause).orderBy(callsTable.startedAt).limit(limit).offset(offset);

  res.json(ListCallsResponse.parse({ data, total: Number(total), page, limit }));
});

router.post("/calls", async (req, res): Promise<void> => {
  const parsed = CreateCallBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [call] = await db.insert(callsTable).values(parsed.data).returning();
  res.status(201).json(GetCallResponse.parse(call));
});

router.get("/calls/active", async (req, res): Promise<void> => {
  const qp = ListActiveCallsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const conditions = [eq(callsTable.status, "active")];
  if (qp.data.facilityId) conditions.push(eq(callsTable.facilityId, qp.data.facilityId));
  const calls = await db.select().from(callsTable).where(and(...conditions)).orderBy(callsTable.startedAt);
  res.json(ListActiveCallsResponse.parse(calls));
});

router.get("/calls/stats", async (req, res): Promise<void> => {
  const qp = GetCallStatsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }
  const conditions: ReturnType<typeof eq>[] = [];
  if (qp.data.facilityId) conditions.push(eq(callsTable.facilityId, qp.data.facilityId));
  const whereClause = conditions.length ? and(...conditions) : undefined;

  const [stats] = await db.select({
    totalCalls: sql<number>`count(*)`,
    completedCalls: sql<number>`count(*) filter (where status = 'completed')`,
    activeCalls: sql<number>`count(*) filter (where status = 'active')`,
    flaggedCalls: sql<number>`count(*) filter (where is_flagged = true)`,
    blockedCalls: sql<number>`count(*) filter (where status = 'blocked')`,
    totalSeconds: sql<number>`coalesce(sum(duration_seconds),0)`,
    avgDuration: sql<number>`coalesce(avg(duration_seconds),0)`,
    totalRevenue: sql<number>`coalesce(sum(cost_amount),0)`,
  }).from(callsTable).where(whereClause);

  res.json(GetCallStatsResponse.parse({
    totalCalls: Number(stats.totalCalls),
    completedCalls: Number(stats.completedCalls),
    activeCalls: Number(stats.activeCalls),
    flaggedCalls: Number(stats.flaggedCalls),
    blockedCalls: Number(stats.blockedCalls),
    totalMinutes: Number(stats.totalSeconds) / 60,
    averageDurationSeconds: Number(stats.avgDuration),
    totalRevenue: Number(stats.totalRevenue),
    peakHour: null,
  }));
});

router.get("/calls/:id", async (req, res): Promise<void> => {
  const params = GetCallParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, params.data.id));
  if (!call) {
    res.status(404).json({ error: "Call not found" });
    return;
  }
  res.json(GetCallResponse.parse(call));
});

router.patch("/calls/:id", async (req, res): Promise<void> => {
  const params = UpdateCallParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateCallBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [call] = await db.update(callsTable).set({
    ...parsed.data,
    costAmount: numericStr(parsed.data.costAmount),
  } as any).where(eq(callsTable.id, params.data.id)).returning();
  if (!call) {
    res.status(404).json({ error: "Call not found" });
    return;
  }
  res.json(UpdateCallResponse.parse(call));
});

router.delete("/calls/:id", async (req, res): Promise<void> => {
  const params = DeleteCallParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [call] = await db.delete(callsTable).where(eq(callsTable.id, params.data.id)).returning();
  if (!call) {
    res.status(404).json({ error: "Call not found" });
    return;
  }
  res.sendStatus(204);
});

router.patch("/calls/:id/flag", async (req, res): Promise<void> => {
  const params = FlagCallParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = FlagCallBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [call] = await db.update(callsTable)
    .set({ isFlagged: true, flagReason: parsed.data.reason, flaggedBy: parsed.data.flaggedBy ?? null, status: "flagged" })
    .where(eq(callsTable.id, params.data.id)).returning();
  if (!call) {
    res.status(404).json({ error: "Call not found" });
    return;
  }
  res.json(FlagCallResponse.parse(call));
});

router.patch("/calls/:id/terminate", async (req, res): Promise<void> => {
  const params = TerminateCallParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [call] = await db.update(callsTable)
    .set({ status: "failed", endedAt: new Date() })
    .where(eq(callsTable.id, params.data.id)).returning();
  if (!call) {
    res.status(404).json({ error: "Call not found" });
    return;
  }
  res.json(TerminateCallResponse.parse(call));
});

export default router;
