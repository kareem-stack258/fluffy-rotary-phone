import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, facilitiesTable, inmatesTable, callsTable, alertsTable, contactsTable, messagesTable, accountsTable } from "@workspace/db";
import { numericStr } from "../lib/coerce";
import {
  GetFacilityParams,
  GetFacilityResponse,
  UpdateFacilityParams,
  UpdateFacilityBody,
  UpdateFacilityResponse,
  DeleteFacilityParams,
  ListFacilitiesResponse,
  CreateFacilityBody,
  GetFacilityStatsParams,
  GetFacilityStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/facilities", async (req, res): Promise<void> => {
  const facilities = await db.select().from(facilitiesTable).orderBy(facilitiesTable.name);
  res.json(ListFacilitiesResponse.parse(facilities));
});

router.post("/facilities", async (req, res): Promise<void> => {
  const parsed = CreateFacilityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [facility] = await db.insert(facilitiesTable).values({
    ...parsed.data,
    callRatePerMinute: numericStr(parsed.data.callRatePerMinute),
    messageRateEach: numericStr(parsed.data.messageRateEach),
  } as any).returning();
  res.status(201).json(GetFacilityResponse.parse(facility));
});

router.get("/facilities/:id", async (req, res): Promise<void> => {
  const params = GetFacilityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [facility] = await db.select().from(facilitiesTable).where(eq(facilitiesTable.id, params.data.id));
  if (!facility) {
    res.status(404).json({ error: "Facility not found" });
    return;
  }
  res.json(GetFacilityResponse.parse(facility));
});

router.patch("/facilities/:id", async (req, res): Promise<void> => {
  const params = UpdateFacilityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateFacilityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [facility] = await db.update(facilitiesTable).set({
    ...parsed.data,
    callRatePerMinute: numericStr(parsed.data.callRatePerMinute),
    messageRateEach: numericStr(parsed.data.messageRateEach),
  } as any).where(eq(facilitiesTable.id, params.data.id)).returning();
  if (!facility) {
    res.status(404).json({ error: "Facility not found" });
    return;
  }
  res.json(UpdateFacilityResponse.parse(facility));
});

router.delete("/facilities/:id", async (req, res): Promise<void> => {
  const params = DeleteFacilityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [facility] = await db.delete(facilitiesTable).where(eq(facilitiesTable.id, params.data.id)).returning();
  if (!facility) {
    res.status(404).json({ error: "Facility not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/facilities/:id/stats", async (req, res): Promise<void> => {
  const params = GetFacilityStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const fid = params.data.id;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString();

  const [inmateCount] = await db.select({ total: sql<number>`count(*)`, active: sql<number>`count(*) filter (where status = 'active')` }).from(inmatesTable).where(eq(inmatesTable.facilityId, fid));
  const [callsToday] = await db.select({ total: sql<number>`count(*)`, active: sql<number>`count(*) filter (where status = 'active')` }).from(callsTable).where(sql`facility_id = ${fid} and started_at >= ${todayStr}`);
  const [openAlerts] = await db.select({ count: sql<number>`count(*)` }).from(alertsTable).where(sql`facility_id = ${fid} and status in ('open','investigating')`);
  const [pendingContacts] = await db.select({ count: sql<number>`count(*)` }).from(contactsTable).where(sql`inmate_id in (select id from inmates where facility_id = ${fid}) and status = 'pending'`);
  const [pendingMsgs] = await db.select({ count: sql<number>`count(*)` }).from(messagesTable).where(sql`facility_id = ${fid} and status = 'pending'`);
  const [lowBal] = await db.select({ count: sql<number>`count(*)` }).from(accountsTable).where(sql`facility_id = ${fid} and balance < 5.00 and status = 'active'`);
  const [rev] = await db.select({ total: sql<number>`coalesce(sum(cost_amount),0)` }).from(callsTable).where(sql`facility_id = ${fid} and cost_amount is not null`);

  res.json(GetFacilityStatsResponse.parse({
    facilityId: fid,
    totalInmates: Number(inmateCount?.total ?? 0),
    activeInmates: Number(inmateCount?.active ?? 0),
    totalCallsToday: Number(callsToday?.total ?? 0),
    activeCallsNow: Number(callsToday?.active ?? 0),
    totalMinutesToday: 0,
    totalRevenue: Number(rev?.total ?? 0),
    openAlerts: Number(openAlerts?.count ?? 0),
    pendingContactApprovals: Number(pendingContacts?.count ?? 0),
    pendingMessages: Number(pendingMsgs?.count ?? 0),
    lowBalanceAccounts: Number(lowBal?.count ?? 0),
  }));
});

export default router;
