import { Router, type IRouter } from "express";
import healthRouter from "./health";
import facilitiesRouter from "./facilities";
import inmatesRouter from "./inmates";
import contactsRouter from "./contacts";
import callsRouter from "./calls";
import messagesRouter from "./messages";
import accountsRouter from "./accounts";
import transactionsRouter from "./transactions";
import staffRouter from "./staff";
import alertsRouter from "./alerts";
import recordingsRouter from "./recordings";
import restrictionsRouter from "./restrictions";
import schedulesRouter from "./schedules";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use(facilitiesRouter);
router.use(inmatesRouter);
router.use(contactsRouter);
router.use(callsRouter);
router.use(messagesRouter);
router.use(accountsRouter);
router.use(transactionsRouter);
router.use(staffRouter);
router.use(alertsRouter);
router.use(recordingsRouter);
router.use(restrictionsRouter);
router.use(schedulesRouter);
router.use(reportsRouter);

export default router;
