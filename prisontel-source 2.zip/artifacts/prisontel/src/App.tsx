import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { ThemeProvider } from "next-themes";

import Dashboard from "@/pages/dashboard";
import Facilities from "@/pages/facilities";
import Inmates from "@/pages/inmates";
import InmateDetail from "@/pages/inmate-detail";
import Calls from "@/pages/calls";
import CallDetail from "@/pages/call-detail";
import Messages from "@/pages/messages";
import Contacts from "@/pages/contacts";
import Accounts from "@/pages/accounts";
import Transactions from "@/pages/transactions";
import Alerts from "@/pages/alerts";
import Recordings from "@/pages/recordings";
import Restrictions from "@/pages/restrictions";
import Schedules from "@/pages/schedules";
import Staff from "@/pages/staff";
import Reports from "@/pages/reports";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/facilities" component={Facilities} />
      <Route path="/inmates" component={Inmates} />
      <Route path="/inmates/:id" component={InmateDetail} />
      <Route path="/calls" component={Calls} />
      <Route path="/calls/:id" component={CallDetail} />
      <Route path="/messages" component={Messages} />
      <Route path="/contacts" component={Contacts} />
      <Route path="/accounts" component={Accounts} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/alerts" component={Alerts} />
      <Route path="/recordings" component={Recordings} />
      <Route path="/restrictions" component={Restrictions} />
      <Route path="/schedules" component={Schedules} />
      <Route path="/staff" component={Staff} />
      <Route path="/reports" component={Reports} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
