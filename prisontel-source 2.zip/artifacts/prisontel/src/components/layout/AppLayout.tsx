import React from "react";
import { Link, useLocation } from "wouter";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Activity, AlertTriangle, Building, CreditCard, FileText, Phone, Settings, ShieldAlert, Users, PhoneCall, MessageSquare, Ban, Calendar, ActivitySquare, BadgeDollarSign } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

const navItems = [
  { title: "Dashboard", href: "/", icon: ActivitySquare },
  { title: "Facilities", href: "/facilities", icon: Building },
  { title: "Inmates", href: "/inmates", icon: Users },
  { title: "Call Center", href: "/calls", icon: PhoneCall },
  { title: "Messages", href: "/messages", icon: MessageSquare },
  { title: "Contacts", href: "/contacts", icon: Phone },
  { title: "Accounts", href: "/accounts", icon: CreditCard },
  { title: "Transactions", href: "/transactions", icon: BadgeDollarSign },
  { title: "Security Alerts", href: "/alerts", icon: ShieldAlert },
  { title: "Recordings", href: "/recordings", icon: Activity },
  { title: "Restrictions", href: "/restrictions", icon: Ban },
  { title: "Schedules", href: "/schedules", icon: Calendar },
  { title: "Staff", href: "/staff", icon: ShieldAlert },
  { title: "Reports", href: "/reports", icon: FileText },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="border-r border-sidebar-border" variant="sidebar" collapsible="icon">
          <SidebarHeader className="border-b border-sidebar-border/50 py-4 px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-lg tracking-tight">
              <ShieldAlert className="h-6 w-6 text-primary" />
              <span className="truncate">PrisonTel</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60 mb-2">
                Operations
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton asChild isActive={location === item.href} tooltip={item.title}>
                        <Link href={item.href} className="flex items-center gap-3 w-full">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>
        
        <main className="flex-1 flex flex-col min-w-0">
          <header className="h-16 border-b bg-card flex items-center justify-between px-6 shrink-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="-ml-2" />
              <h1 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Command Center</h1>
            </div>
            <div className="flex items-center gap-4">
              <ThemeToggle />
            </div>
          </header>
          <div className="flex-1 overflow-auto p-6 md:p-8">
            <div className="mx-auto max-w-7xl">
              {children}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
